package es.tiw.admin.model;

public class User {

	

	private int idusuario;
	private String usuario;
	private String completeName;
	private String passwd;
	private String direction;
	private String telf;
	private String permisos;
	
	public User() {
	}
	
	public User(int idusuario, String user, String completeName, String password, String direction, String phone, String permisos) {
		super();
		this.idusuario = idusuario;
		this.usuario = user;
		this.completeName = completeName;
		this.passwd = password;
		this.direction = direction;
		this.telf = phone;
		this.permisos=permisos;
	}
	
	

	public String getPermisos() {
		return permisos;
	}


	public void setPermisos(String permisos) {
		this.permisos = permisos;
	}


	public int getIdusuario() {
		return idusuario;
	}

	public void setIdusuario(int iduser) {
		this.idusuario = iduser;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String user) {
		this.usuario = user;
	}

	public String getcompleteName() {
		return completeName;
	}

	public void setcompleteName(String completeName) {
		this.completeName = completeName;
	}

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String password) {
		this.passwd = password;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getTelf() {
		return telf;
	}

	public void setTelf(String phone) {
		this.telf = phone;
	}
}

