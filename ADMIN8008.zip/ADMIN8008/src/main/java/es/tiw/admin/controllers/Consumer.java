
package es.tiw.admin.controllers;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import es.tiw.admin.model.User;
import es.tiw.admin.model.Event;
import es.tiw.admin.model.Ticket;

@MultipartConfig
@CrossOrigin
@Controller
public class Consumer {

	@Autowired
	RestTemplate restTemplate;
	
	//
	//Inicio de las Operaciones sobre los usuarios
	//
	
		//viewTodosUsuarios
		@RequestMapping (value = "userRead", method = RequestMethod.GET)
		public String returnTodosUsuarios(Model modelo) {
			User[] listaUs = restTemplate.getForObject("http://localhost:8082/usuarios", User[].class);
			System.out.println("La lista tiene :"+listaUs.length+ " elementos");
			modelo.addAttribute("usuariosLista", listaUs);
			return "userRead.html";
			
		}
		
		
		// Eliminacion de un usuario, despues a enseñar todos los usuarios restantes
		@RequestMapping (value = "/usuarios/remove/{idusuario}")
		public String removeUser( Model modelo,@PathVariable Integer idusuario) {
	
			User[] listaUs =restTemplate.getForObject("http://localhost:8082/usuarios/remove/{idusuario}", User[].class, idusuario);
			modelo.addAttribute("usuariosLista", listaUs);
			return "userRead.html";
			
		}
	
		
		// Vista editar un usuario, busca ese usuario y carga los datos en la vista para rellenar un form y ya editarlo con el metodo EditUser
		@RequestMapping(value="/usuario/edit/{idusuario}")
		public  String EditUserView(@PathVariable Integer idusuario, Model modelo){
			
			User us = restTemplate.getForObject("http://localhost:8082/usuarios/edit/{idusuario}", User.class, idusuario);
			modelo.addAttribute("usuario", us);
			return "userEdit.html";
		
		}	
		
		
		// Editar un usuario, despues muestra los usuarios restantes
		
			@RequestMapping(value="/usuario/edit/", method=RequestMethod.POST)
			public  String EditUser( @ModelAttribute User us, Model modelo){
				
				restTemplate.put("http://localhost:8082/usuario/", us ,User.class);
				User[] listaUs = restTemplate.getForObject("http://localhost:8082/usuarios", User[].class);
				modelo.addAttribute("usuariosLista", listaUs);
				return "userRead";
			}
			
			//redirige a add
			@RequestMapping (value = "/userAdd", method = RequestMethod.GET)
			public String returnUserAdd() {
				
				return "userAdd.html";
				
			}
			
		// Añade un usuario y muestra la vista de usuarios
			@RequestMapping(value="/usuario/add/", method=RequestMethod.POST)
			public  String AddUser( @ModelAttribute User us, Model modelo){
				
				restTemplate.put("http://localhost:8082/usuario/add", us ,User.class);
				User[] listaUs = restTemplate.getForObject("http://localhost:8082/usuarios", User[].class);
				modelo.addAttribute("usuariosLista", listaUs);
				return "userRead";
				}

	//
	//Inicio de las Operaciones sobre los eventos
	//
	 
			//viewTodosEventos
			@RequestMapping (value = "eventRead", method = RequestMethod.GET)
			public String returnTodosEventos(Model modelo) {
				Event[] listaEv = restTemplate.getForObject("http://localhost:8083/eventos", Event[].class);
				System.out.println("La lista tiene :"+listaEv.length+ " elementos");
				modelo.addAttribute("eventosLista", listaEv);
				return "eventRead.html";

			}
			
			// Eliminacion de un evento, despues a enseñar todos los evenots restantes
			@RequestMapping (value = "/eventos/remove/{idevento}")
			public String removeEvent( Model modelo,@PathVariable Integer idevento) {
		
				Event[] listaEv =restTemplate.getForObject("http://localhost:8083/eventos/remove/{idevento}", Event[].class, idevento);
				modelo.addAttribute("eventosLista", listaEv);
				return "eventRead.html";
				
			}
			
			
			// Vista editar un usuario, busca ese usuario y carga los datos en la vista para rellenar un form y ya editarlo con el metodo EditUser
			@RequestMapping(value="/evento/edit/{idevento}")
			public  String EditEventView(@PathVariable  Integer idevento, Model modelo){
				
				Event ev = restTemplate.getForObject("http://localhost:8083/eventos/edit/{idevento}", Event.class, idevento);
				modelo.addAttribute("evento", ev);
				return "eventEdit";
			
			}	
			

			// Editar un EVENTO, despues muestra los EVENTOS restantes
			@RequestMapping(value="/evento/edit/", method=RequestMethod.POST)
			public  String EditEvent( @ModelAttribute Event ev, Model modelo) throws Exception{
		
				restTemplate.put("http://localhost:8083/evento/", ev ,Event.class);
				Event[] listaEv = restTemplate.getForObject("http://localhost:8083/eventos", Event[].class);
				modelo.addAttribute("eventosLista", listaEv);
				return "eventRead";
				}
			
				
			//redirige a add event
			@RequestMapping (value = "/eventAdd", method = RequestMethod.GET)
			public String returnEventAdd() {
				
				return "eventAdd.html";
				
			}
			
			// Añade evento y muestra la vista de eventos
			@RequestMapping(value="/evento/add/", method=RequestMethod.POST)
			public  String AddEvent( @ModelAttribute Event ev, Model modelo, @RequestParam("img")MultipartFile myfile ) throws Exception{
				
				ev.setEventPicture(myfile.getBytes());
				restTemplate.put("http://localhost:8083/evento/add", ev ,Event.class);
				Event[] listaEv = restTemplate.getForObject("http://localhost:8083/eventos", Event[].class);
				modelo.addAttribute("eventosLista", listaEv);
				return "eventRead.html";
			}
			


	//
	//Inicio de las Operaciones sobre los tickets
	//
			
			 //viewTodosTickets
			@RequestMapping (value = "/ticketRead/{idevento}", method = RequestMethod.GET)
			public String returnTickets(Model modelo,@PathVariable Integer idevento) {
				Ticket[] listaTic = restTemplate.getForObject("http://localhost:8084/tickets/{idevento}", Ticket[].class, idevento);
				modelo.addAttribute("ticketsLista", listaTic);
				modelo.addAttribute("idevento", idevento);
				if (listaTic==null) {
					return "ticketRead.html"; // es una pagina que te avisa de que no hay tickets para ese evento
				}
				else {
					return "ticketsRead.html";
				}

			}
			
			// Eliminar de un ticket, despues a enseñar todos los tickets restantes
			@RequestMapping (value = "/ticket/remove/{idtickets}")
			public String removeTicket( Model modelo,@PathVariable Integer idtickets) {
		
				Ticket[] listaTic =restTemplate.getForObject("http://localhost:8084/tickets/remove/{idtickets}", Ticket[].class, idtickets);
				modelo.addAttribute("ticketsLista", listaTic);
				if (listaTic==null) {
					return "ticketRead.html"; // es una pagina que te avisa de que no hay tickets para ese evento
				}
				else {
					return "ticketsRead.html";
				}
				
			}
			
			// Vista editar un Ticket, busca ese Ticket y carga los datos en la vista para rellenar un form y ya editarlo con el metodo EditTicket
			@RequestMapping(value="/ticket/edit/{idtickets}")
			public  String EditTicketView(@PathVariable  Integer idtickets, Model modelo){
							
				Ticket tic = restTemplate.getForObject("http://localhost:8084/ticket/{idtickets}", Ticket.class, idtickets);
				modelo.addAttribute("ticket", tic);
				return "ticketEdit.html";
						
			}	
			
			
			// Editar un TICKET, despues muestra los TICKETS restantes
			@RequestMapping(value="/ticket/edit/", method=RequestMethod.POST)
			public  String editTicket( @ModelAttribute Ticket tic, Model modelo){
				int idevento = tic.getIdevent();
				int idusuario = tic.getUsuario().getIdusuario();
				
				Event event = restTemplate.getForObject("http://localhost:8083/event/{idEvent}", Event.class, idevento);;
				User user = restTemplate.getForObject("http://localhost:8082/users/{idUser}", User.class, idusuario);;
				
				tic.setEvent(event);
				tic.setUsuario(user);
				
				restTemplate.put("http://localhost:8084/tickets/edit/",tic ,Ticket.class);
				Ticket[] listaTic = restTemplate.getForObject("http://localhost:8084/tickets/{idevento}", Ticket[].class, idevento);
				modelo.addAttribute("ticketsLista", listaTic);
				return "ticketsRead.html";
				}
			
			//redirige a add ticket
			@RequestMapping (value = "/ticketAdd/{idevento}", method = RequestMethod.GET)
			public String returnTicketAdd(@PathVariable  Integer idevento, Model modelo) {
				modelo.addAttribute("idevento", idevento);
				return "ticketAdd.html";
				
			}
			
			// Añade un ticket y muestra la vista de tickets
			@RequestMapping(value="/ticket/add/{idevento}", method=RequestMethod.POST)
			public  String addTicket( @ModelAttribute Ticket tic, Model modelo, @PathVariable  Integer idevento){
				
				int idusuario = tic.getUsuario().getIdusuario();
				
				Event event = restTemplate.getForObject("http://localhost:8083/event/{idEvent}", Event.class, idevento);
				User user = restTemplate.getForObject("http://localhost:8082/users/{idUser}", User.class, idusuario);
				
				tic.setEvent(event);
				tic.setUsuario(user);
				
				restTemplate.put("http://localhost:8084/admin/tickets/add", tic ,Ticket.class);
				Ticket[] listaTic = restTemplate.getForObject("http://localhost:8084/tickets/{idevento}", Ticket[].class, idevento);
				modelo.addAttribute("ticketsLista", listaTic);
				return "ticketsRead.html";
			}
			
		
			// mover
			@GetMapping("/event/image/{id}")
			public void showProductImage(@PathVariable Integer id, HttpServletResponse response) throws IOException {
			
				response.setContentType("image/jpeg"); 
				Event event = restTemplate.getForObject("http://localhost:8083/event/{idEvent}", Event.class, id);
				InputStream is = new ByteArrayInputStream(event.getEventPicture());
				IOUtils.copy(is, response.getOutputStream());
			}
			
			
}
