package es.tiw.admin.model;

import es.tiw.admin.model.Event;
import es.tiw.admin.model.User;

public class Ticket {

		private int idtickets;
		private User usuario;
		private int numbefOfTickets;
		private String ticketsType;
		private int totalCost;
		private Event event;

		public Ticket() {
			// TODO Auto-generated constructor stub
		}
		public Ticket(int idtickets, int numbefOfTickets, String ticketsType, int totalCost, Event event, User usuario) {
			super();
			this.idtickets = idtickets;
			this.event = event;
			this.usuario = usuario;
			this.numbefOfTickets = numbefOfTickets;
			this.ticketsType = ticketsType;
			this.totalCost = totalCost;

		}
		public int getIdtickets() {
			return idtickets;
		}
		public void setIdtickets(int idtickets) {
			this.idtickets = idtickets;
		}
		public int getIdevent() {
			return event.getIdevento();
		}
		public void setIdevent(int id) {
			this.event.setIdevento(id);
		}
		
		public int getNumbefOfTickets() {
			return numbefOfTickets;
		}
		public void setNumbefOfTickets(int numbefOfTickets) {
			this.numbefOfTickets = numbefOfTickets;
		}
		public String getTicketsType() {
			return ticketsType;
		}
		public void setTicketsType(String ticketsType) {
			this.ticketsType = ticketsType;
		}
		public int getTotalCost() {
			return totalCost;
		}
		public void setTotalCost(int totalCost) {
			this.totalCost = totalCost;
		}
		public Event getEvent() {

			return event;
		}
		public void setEvent(Event event) {
			this.event = event;
		}
		public User getUsuario() {

			return usuario;
		}
		public void setUsuario(User usuario) {
			this.usuario = usuario;
		}


	

		

	}
