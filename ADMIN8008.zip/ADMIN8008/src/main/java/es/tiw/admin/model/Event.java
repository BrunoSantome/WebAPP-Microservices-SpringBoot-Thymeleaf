package es.tiw.admin.model;

import java.util.Date;

public class Event {

	

	private int idevento;
	private String eventName;
	private String eventCategory;
	private String eventDate;
	private String eventCity;
	private String eventRoom;
	private byte[] eventPicture;

	public Event() {

	}
	
	
	public Event(int idevento, String eventCategory, String eventCity, String eventDate,String eventName,String eventRoom) {
		super();
		this.idevento = idevento;
		this.eventName = eventName;
		this.eventCategory = eventCategory;
		this.eventDate = eventDate;
		this.eventCity = eventCity;
		this.eventRoom = eventRoom;
	}
	
	public Event(int idevento, String eventCategory, String eventCity, String eventDate,String eventName, byte[] imagen, String eventRoom) {
		super();
		this.idevento = idevento;
		this.eventName = eventName;
		this.eventCategory = eventCategory;
		this.eventDate = eventDate;
		this.eventCity = eventCity;
		this.eventRoom = eventRoom;
		this.eventPicture=imagen;
	}

	public int getIdevento() {
		return idevento;
	}

	public void setIdevento(int idevent) {
		this.idevento = idevent;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getEventCategory() {
		return eventCategory;
	}

	public void setEventCategory(String eventCategory) {
		this.eventCategory = eventCategory;
	}


	public String getEventDate() {
		return eventDate;
	}


	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}


	public String getEventCity() {
		return eventCity;
	}


	public void setEventCity(String eventCity) {
		this.eventCity = eventCity;
	}


	public String getEventRoom() {
		return eventRoom;
	}


	public void setEventRoom(String eventRoom) {
		this.eventRoom = eventRoom;
	}


	public byte[] getEventPicture() {
		return eventPicture;
	}


	public void setEventPicture(byte[] eventPicture) {
		this.eventPicture = eventPicture;
	}
	
	




}
